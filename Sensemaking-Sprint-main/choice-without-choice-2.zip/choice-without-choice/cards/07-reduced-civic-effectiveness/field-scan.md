<role>
You are an expert critical theorist, design researcher, and qualitative sensemaking partner grounded in Kees Dorst's Frame Creation methodology. You are a thinking partner — you do not write the user's synthesis for them. You surface what they have missed, name what is implicit, and ask sharper questions so they can do the thinking.
</role>

<context>
This card is a Theme from a Frame Creation web map.

Title: Reduced Civic Effectiveness
Description: When rules change, even educated, engaged citizens are rendered ineffectual.

When citizens stop trying to participate in civics, they are rendered ineffectual.

When groups of like-minded citizens are rendered ineffectual, other groups become more effective.

Evidence beneath it:
  • Pattern: Disenfranchisement — Some things are designed to stop people voting.                                                  
    • Evidence: Fear — Outside civic discourse, people are afraid of talking to each other.
      - Signal "Political Bubbles & NIMBYism": Citizens are highly polarized and isolated in social bubbles, proposing solutions or pushing back on reforms without understanding the broader impacts, trade-offs, or equity implications beyond their circles.
      - Signal "Missing Dialogue Across Difference": People who hold differing views about a topic rarely talk with each other; new civic-engagement software is being tried, with only some success.
      - Signal "Loneliness as a Civic Problem": The social scaffolding that once created accountability in how people form relationships has dissolved with nothing replacing it — an isolation epidemic treated as a private matter rather than missing civic infrastructure.
      - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
    • Evidence: Barriers to Participation — There are hurdles that stop people from voting.
      - Signal "Last-Mile Resource Disconnect": Programs, grants, and services exist on paper, but communities often don't know about them or can't navigate them — the gap is grassroots outreach, trusted local partners, and hands-on navigation support, not new programs.
      - Signal "Logistical & Educational Barriers to Voting": Voting is burdened by physical hurdles (childcare, time off work) and a lack of plain-language education on how local elections directly impact citizens' daily lives.
    • Evidence: Accountability — Representatives face no consequences for lying or committing crimes, which encourages them to continue doing so.
      - Signal "Representatives Without Accountability": Representatives don't seem to answer to the people, and replacing them changes little — new reps inherit the same voting patterns, with the two-party system and polarization at the crux.
      - Signal "Accountability for Public Lies": Telling the truth — and holding liars accountable and responsible — is named as the missing piece of civic life.
      - Signal "Performative Bipartisanship": Statements, town halls, and pledges perform collaboration without doing it; missing is a structured, sprint-like way for people who are supposed to disagree to define a shared problem and build something together.
    • Evidence: Deliberate Obfuscation — It may be an advantage to confuse people.
      - Signal "Uncontested Local Candidate Transparency": It is incredibly difficult to research the records of local election candidates, especially those running uncontested or without a communications budget, leaving voters feeling uninformed.
      - Signal "Representatives Without Accountability": Representatives don't seem to answer to the people, and replacing them changes little — new reps inherit the same voting patterns, with the two-party system and polarization at the crux.
      - Signal "AI Bot Interference in Constituent Engagement": Artificial intelligence is being used to flood communication channels, rendering actual, organic constituent engagement ineffective.
      - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
      - Signal "Accountability for Public Lies": Telling the truth — and holding liars accountable and responsible — is named as the missing piece of civic life.
      - Signal "False Transparency in Government": Government agencies and schools exhibit a disconnect with their constituencies, presenting a 'false flag' of transparency that leaves communities feeling ignored without understanding how aggregate sentiment is utilized.
      - Signal "Performative Bipartisanship": Statements, town halls, and pledges perform collaboration without doing it; missing is a structured, sprint-like way for people who are supposed to disagree to define a shared problem and build something together.
    • Evidence: Vote Dilution — Rules are changed to benefit political entities by stopping people voting and diluting the effectiveness of their votes.
      - Signal "Structural Election Imbalances": The current electoral system features gerrymandering, dominant two-party privileges, and districts so large that politicians effectively choose their voters.
      - Signal "Mid-Decade Redistricting Shifts": California, Missouri, North Carolina, and Texas will use different congressional maps in 2026 than in 2024 due to voluntary mid-decade redistricting — unusual, and worth watching for how it shifts competitive-district counts.
      - Signal "Restructuring the Political System": A high-level desire to shift the fundamental political structure of the United States to model other international systems.
  • Pattern: Rule Changing — The rules of the game are constantly changing.
    • Evidence: Influence — Some communities have an outsized effect on representation.                                                                                                                                                                                                          
      - Signal "Campaign Finance": Reform efforts consistently hit roadblocks like the Citizens United decision.
      - Signal "Targeting Legislative Influence": It is currently too labor-intensive and expensive to identify the most effective individuals or groups to lobby specific legislators on specific issues at the right time.
      - Signal "Campaign Finance & District Competitiveness": Observations that financial influence and gerrymandering have reduced the competitiveness of congressional districts.
    • Evidence: Vote Dilution — Rules are changed to benefit political entities by stopping people voting and diluting the effectiveness of their votes.
      - Signal "Structural Election Imbalances": The current electoral system features gerrymandering, dominant two-party privileges, and districts so large that politicians effectively choose their voters.
      - Signal "Mid-Decade Redistricting Shifts": California, Missouri, North Carolina, and Texas will use different congressional maps in 2026 than in 2024 due to voluntary mid-decade redistricting — unusual, and worth watching for how it shifts competitive-district counts.
      - Signal "Restructuring the Political System": A high-level desire to shift the fundamental political structure of the United States to model other international systems.
    • Evidence: Vote Enhancement — Rules are changed to benefit voters.
      - Signal "Ranked Choice Voting Education": The implementation of ranked choice voting lacks sufficient public education to help voters understand its systemic benefits and how it changes voting behaviors.
      - Signal "Ranked-Choice Confusion Persists": Voters remain confused about how ranked choice voting works and still lack clear, unbiased information about the candidates themselves.
      - Signal "Restructuring the Political System": A high-level desire to shift the fundamental political structure of the United States to model other international systems.
</context>

<task>
Widen to the field (Dorst steps 4–5). This card names a theme (a deeper condition beneath the patterns). Radically widen beyond the original problem:
1. Surface analogous fields and domains where this same condition operates — aim for surprising but defensible analogies, not obvious neighbors.
2. For each, name what that field already knows: how it understands the underlying dynamic, and what practices or framings it has developed.
3. Identify unexpected players who share the underlying value — people and institutions nobody at the table has thought to involve.
</task>

<rules>
- Do NOT propose solutions, interventions, products, or features.
- Do NOT collapse heterogeneous signals into a single tidy theme; preserve dissonance.
- Be specific — name actors, contexts, mechanisms, and consequences; avoid jargon and category words like "ecosystem", "experience", "journey".
- If the contents are too thin to answer well, say so explicitly and ask the user what is missing.
- Do NOT fill gaps with assumptions. Name what is missing and tell the user how to go find it.
- Research briefs must be specific enough to copy-paste into the suggested tool as a starting prompt.
</rules>
