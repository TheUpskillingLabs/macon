# Fear

*Evidence · Evidence*

Outside civic discourse, people are afraid of talking to each other.

## Built from

  - Signal "Political Bubbles & NIMBYism": Citizens are highly polarized and isolated in social bubbles, proposing solutions or pushing back on reforms without understanding the broader impacts, trade-offs, or equity implications beyond their circles.
  - Signal "Missing Dialogue Across Difference": People who hold differing views about a topic rarely talk with each other; new civic-engagement software is being tried, with only some success.
  - Signal "Loneliness as a Civic Problem": The social scaffolding that once created accountability in how people form relationships has dissolved with nothing replacing it — an isolation epidemic treated as a private matter rather than missing civic infrastructure.
  - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
