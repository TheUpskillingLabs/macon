# Limited Access

> **Pattern** — a card in a Frame Creation web map.
> Built from 4 signal(s). The work on this page is to *investigate the field*, not to solve.

## The mechanism
*Not a topic — a mechanism. Cause → effect, with moving parts. What makes this happen?*

## When and where it recurs
*The conditions under which the pattern shows up. Who's affected, in what context?*

## How the evidence beneath supports it
*Walk each evidence card: how does it establish the mechanism? Where is the chain strongest and weakest?*

## What would have to change to break it
*The leverage points — named, not yet acted on.*

## Where it doesn't hold
*Counter-cases. Honest patterns name their own exceptions.*

---

## Evidence & sources
*Primary (from the situation itself — interviews, field notes, documents) and secondary (literature, data, prior art). Attach files below; list and annotate them here.*

## Where I'm not sure
*Your confidence. What would change your mind? What would falsify this?*

## Whose voice is still missing
*Who hasn't been heard yet — and how would they complicate this?*

Frame Creation Level: Pattern Synthesis
As we move up the synthesis ladder to the Pattern level, we need to uncover the recurring, structural engine that links these two evidence cards (Accessibility impacts engagement + Minority group limited access).

Through-line candidate
Institutional offloading of structural costs onto marginalized actors: public systems default to designing processes that assume surplus wealth, flexible time, and baseline infrastructure, forcing individuals and under-resourced cohorts to absorb the material and cognitive tax of participating or competing.

Why this fits
"Logistical & Educational Barriers to Voting": Directly demonstrates how the state offloads operational costs (childcare, lost wages, time off work) onto working citizens as a prerequisite for exercising a basic democratic right.

"Student Technology Access Gap": Shows how underfunded public institutions push the cost of basic educational infrastructure onto local communities, forcing reliance on private fundraising or ad-hoc lobbying to bridge systemic gaps.

"Local Candidate Information Gaps": Illustrates how the failure to provide plain-language, centralized candidate data transfers the cognitive labor of research onto voters, forcing them to rely on low-fidelity shortcuts like yard signs.

Shared condition: Every signal reveals a system that externalizes its friction onto the user, treating baseline access as a luxury that actors must self-subsidize.

What does not fit
"Women Still Under-Represented": While under-representation in political leadership involves systemic bias and gatekeeping, it does not cleanly share the same operational mechanism as material infrastructure deficits (lacking laptops, missing voting leave, missing plain-language guides). It reflects political power-hoarding and cultural gatekeeping rather than cost-offloading.

"People need more structural and institutional support" (Current Description): This statement names a missing intervention rather than a mechanism. It frames the pattern as a passive lack of help, hiding the active structural choices that create these barriers in the first place.

Sharpening question
Are these barriers recurring because institutions are simply under-resourced, or because the default design of civic systems intentionally favors participants who can afford to absorb these costs?
