# Untitled

> **Evidence · Evidence** — a card in a Frame Creation web map.
> Built from 2 signal(s). The work on this page is to *investigate the field*, not to solve.

## What these signals jointly establish
*Two or more signals triangulating on one claim. State the claim they make together.*

## What kind of evidence is this?
*Decide the movement first — are you excavating the known problem (Archaeology & Context: history, counterfactual, problem, boundary, flux) or widening to the players and values of the field (Field mapping: player, value)? Classify it once the situation is mapped, then deepen with the matching prompts.*

---

## Evidence & sources
*Primary (from the situation itself — interviews, field notes, documents) and secondary (literature, data, prior art). Attach files below; list and annotate them here.*

## Where I'm not sure
*Your confidence. What would change your mind? What would falsify this?*

## Whose voice is still missing
*Who hasn't been heard yet — and how would they complicate this?*

Through-line candidate
An institutional immunity loop where political representatives are structurally shielded from truth-based consequences because party polarization—not civic accountability—dictates their survival.

Why this fits
Systemic immunity across transitions ("Representatives Without Accountability"): Pointing directly to a structural mechanism where replacing individual actors yields identical voting patterns, showing the friction is systemic rather than behavioral.

Absence of truth enforcement ("Accountability for Public Lies"): Highlights the missing structural affordance (a mechanism to enforce truth) that allows public officials to issue unchecked statements without career or electoral penalties.

The shared core mechanism: Both signals converge on the breakdown of a feedback loop: public input and truth verification have no leverage over official conduct within the two-party power structure.

What does not fit
The moral/civic framing of "Telling the truth": The signal frames the issue around a normative desire ("civic life needs truth"), which leans toward a value judgment, whereas the rest of the cluster points toward an institutional design failure. It may be here because moral outrage is the observable symptom of the structural brokenness.

Frame Creation Evidence Classification
To classify this card, let's look at the two distinct analytical movements in Dorst’s methodology:

1. ARCHAEOLOGY & CONTEXT (Excavating the known problem and its current state)
If you want this card to anchor the as-is structural condition of the problem space, consider:

Boundary: Fits best if you view this as a rigid, non-negotiable constraint ("The system is designed so officials will never be held accountable by electoral rotation alone").

Problem: Fits if you frame this as a bounded, conventional difficulty—a missing mechanism in public statement verification that needs an institutional fix.

2. FIELD MAPPING (Widening to broader actors or universal values)
If you want to use this card to map the broader human or field dynamics, consider:

Value: Fits if the core of this card is the universal civic demand for Truth or Trust as a foundational necessity for public life.

Player: Fits if you refactor this to focus on Public Officials or The Electorate, defined strictly by their practices (issuing statements without friction) and currency (party allegiance vs. public trust).

The Trade-off
Boundary vs. Value: Classifying as a Boundary keeps your analysis grounded in systemic/institutional mechanics (how power shields itself). Classifying as a Value shifts your lens to the human/civic ethos (what the community feels is missing from public life).

Which analytical movement serves your map better right now?

Sharpening question
Is your primary focus here the structural mechanism that insulates politicians from consequences, or the broader loss of truth/trust as a civic value?