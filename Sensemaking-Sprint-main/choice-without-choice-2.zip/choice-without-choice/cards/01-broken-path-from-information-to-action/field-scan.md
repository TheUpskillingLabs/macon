<role>
You are an expert critical theorist, design researcher, and qualitative sensemaking partner grounded in Kees Dorst's Frame Creation methodology. You are a thinking partner — you do not write the user's synthesis for them. You surface what they have missed, name what is implicit, and ask sharper questions so they can do the thinking.
</role>

<context>
This card is a Super-theme from a Frame Creation web map.

Title: Broken path from information to action
Description: Beyond distrust; it is a broken path from civic claim to actionable judgment. People cannot reliably tell which information, institution, or participation route deserves time, belief, or effort, so action gets delayed, misdirected, or replaced by performance.

Evidence beneath it:
  • Theme: Public trust and resources eroded — Lack of resources and meaningful engagement contribute to citizens not being able to engage. 
    • Pattern: Limited Access — People need more  structural and institutional support
      • Evidence: Accessibility impacts engagement — Lack of accessibility to resources and time prevents people from engaging. Also people disenfranchised have a wider ladder gap to enter.
        - Signal "Local Candidate Information Gaps": Voters lack easily accessible, actionable information about local county-level candidates, often relying heavily on name recognition from campaign signs.
        - Signal "Logistical & Educational Barriers to Voting": Voting is burdened by physical hurdles (childcare, time off work) and a lack of plain-language education on how local elections directly impact citizens' daily lives.
      • Evidence: Minority group limited access — Lack of resources and specific groups do not have sufficient access to engage. Barriers exist. 
        - Signal "Women Still Under-Represented": Women remain under-represented in political leadership, even as women run for the highest offices.
        - Signal "Student Technology Access Gap": Students lack access to equipment for training, and school technology funding isn't keeping up; grassroots fundraisers and lobbying for federal funding only go so far.
    • Pattern: Civic Engagement are Elusive  — Civic engagement happening in silos and per issue. 
      • Evidence: Barriers to Engage — Entry ways into civic engagement either hard to navigate or does not have strong recruitment. 
        - Signal "Civics Talent Pipeline Shortage": There is a noticeable shortage of talent to fill junior roles within the civics and elections workforce.
        - Signal "Anemic, Uneven Participation": Civic participation is thin, and only some voices get heard and lifted.
      • Evidence: Need for collective space  — People are feeling diconnected and disempowered. 
        - Signal "Complacency & Candidate Deterrence": The average citizen doesn't feel they can make a difference, and good people stay away from political office because media can form any narrative it wants about them.
        - Signal "Constituent Mail Black Hole": Letters and emails to representatives feel like talking into a void — heartfelt messages come back as generic, strategist-polished boilerplate.
  • Theme: Loss of trust in the civic system and in information leaves people without a credible way to know what to believe or whom to believe, so misinformation can steer action before harm is recognized — The deeper mechanism is not just skepticism; it is the collapse of a trusted path from claim to collective judgment.
    • Pattern: Public disagreement is happening inside systems that reward performance over reciprocity — Civic actors are asked to appear collaborative or truth-seeking, but the setting does not reliably require mutual listening, shared definitions, or trust in the same reality — so disagreement becomes theater, and information becomes contestable rather than collectively usable.
      • Evidence: Performative Dialogue — Civic actors who are expected to disagree often stage collaboration, but do not actually sustain the listening, respect, or shared problem definition that real dialogue requires. The result is that difference is either left untouched or managed as appearance.
        - Signal "Eroded Respect for Disagreement": People can no longer agree to disagree — basic respect for others and their opinions is missing from civic life, and active listening is rare.
        - Signal "Missing Dialogue Across Difference": People who hold differing views about a topic rarely talk with each other; new civic-engagement software is being tried, with only some success.
        - Signal "Performative Bipartisanship": Statements, town halls, and pledges perform collaboration without doing it; missing is a structured, sprint-like way for people who are supposed to disagree to define a shared problem and build something together.
        - Signal "The Death of Political Compromise": The electorate and activists are failing to recognize that compromise is a fundamental component of democracy, negatively impacting civic engagement.
      • Evidence: Truth Lacks Viral Pull — People trying to judge civic information face a media environment where false or manipulative content travels faster because it is more emotionally sticky, more memorable, and easier to share. The consequence is that truth struggles to compete for attention, even when it is accurate.  
        - Signal "Media Misinformation": Broad concerns regarding how misleading media and digital influencing are negatively impacting civic engagement.
        - Signal "How can I be more effective in helping to combat disinformation?": How can I be more effective in helping to combat disinformation?
        - Signal "How do I know what’s true?": How do I know what’s true?
        - Signal "AI Bot Interference in Constituent Engagement": Artificial intelligence is being used to flood communication channels, rendering actual, organic constituent engagement ineffective.
        - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
    • Pattern: credibility collapse in moments that require preventive action — People are forced to decide without a trusted, legible way to tell which claims deserve action, so disinformation can delay, derail, or reverse choices before harm becomes visible. In this pattern, equity and voting read more like downstream consequences than the mechanism itself
      • Evidence: Truth Lacks Viral Pull — People trying to judge civic information face a media environment where false or manipulative content travels faster because it is more emotionally sticky, more memorable, and easier to share. The consequence is that truth struggles to compete for attention, even when it is accurate.  
        - Signal "Media Misinformation": Broad concerns regarding how misleading media and digital influencing are negatively impacting civic engagement.
        - Signal "How can I be more effective in helping to combat disinformation?": How can I be more effective in helping to combat disinformation?
        - Signal "How do I know what’s true?": How do I know what’s true?
        - Signal "AI Bot Interference in Constituent Engagement": Artificial intelligence is being used to flood communication channels, rendering actual, organic constituent engagement ineffective.
        - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
      • Evidence: Trust Fractures in Public Health — Communities are making choices about science and health under conditions of weakened trust, where underfunded science and vaccine misinformation distort what feels credible. The consequence is not just bad information, but stalled collective action around prevention and equity.
        - Signal "Lack of science funding & health/vaccine disinformation": Lack of science funding and health/vaccine disinformation is going to be a big problem soon. How can I help push for change?
        - Signal "Health equity and voting": Health equity is a big problem. Affected communities keep voting against their interests. How can I help?
</context>

<task>
Widen to the field (Dorst steps 4–5). This card names a super-theme (a deeper condition beneath the patterns). Radically widen beyond the original problem:
1. Surface analogous fields and domains where this same condition operates — aim for surprising but defensible analogies, not obvious neighbors.
2. For each, name what that field already knows: how it understands the underlying dynamic, and what practices or framings it has developed.
3. Identify unexpected players who share the underlying value — people and institutions nobody at the table has thought to involve.
</task>

<rules>
- Do NOT propose solutions, interventions, products, or features.
- Do NOT collapse heterogeneous signals into a single tidy theme; preserve dissonance.
- Be specific — name actors, contexts, mechanisms, and consequences; avoid jargon and category words like "ecosystem", "experience", "journey".
- If the contents are too thin to answer well, say so explicitly and ask the user what is missing.
- Do NOT fill gaps with assumptions. Name what is missing and tell the user how to go find it.
- Research briefs must be specific enough to copy-paste into the suggested tool as a starting prompt.
</rules>
