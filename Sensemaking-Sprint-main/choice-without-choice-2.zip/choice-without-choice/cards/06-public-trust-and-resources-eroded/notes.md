# Untitled

> **Theme** — a card in a Frame Creation web map.
> Built from 8 signal(s). The work on this page is to *investigate the field*, not to solve.

## The deeper condition
*The universal beneath the patterns. What force or condition is hidden under the surface of everyday life here?*

## Bridge test
*Does this name BOTH a structural condition AND a human experience? A theme that lives on only one side is just a restated pattern.*

## Depth test
*Is this hidden beneath the everyday framing? Does it explain things you didn't build it from?*

## The field: where else does this condition live?
*Analogous domains where the same condition operates. What do those fields know that yours doesn't?*

## Tensions it holds
*Don't resolve them. Name the dissonance — that's where frames are born.*

---

## Evidence & sources
*Primary (from the situation itself — interviews, field notes, documents) and secondary (literature, data, prior art). Attach files below; list and annotate them here.*

## Where I'm not sure
*Your confidence. What would change your mind? What would falsify this?*

## Whose voice is still missing
*Who hasn't been heard yet — and how would they complicate this?*

Frame Creation Level: Theme Synthesis
Stepping up to the Theme level means bridging the human experience (disempowerment, fatigue, alienation) with the institutional/economic realm (resource offloading, risk-managed communication, gatekeeping). A strong theme names the deep force operating hidden beneath the surface of civic and professional life.

Through-line candidate
The systematic privatization of civic costs paired with the bureaucratic insulation of public authority: institutions protect their operational stability by deflecting authentic engagement into risk-managed PR channels, while simultaneously shifting the economic, cognitive, and temporal burdens of democratic participation entirely onto individual citizens.

Why this fits
Human Domain (Exhaustion & Alienation): Signals like "Constituent Mail Black Hole" and "Complacency & Candidate Deterrence" show how citizens internalize institutional deflection as personal powerlessness ("talking into a void", "can't make a difference").

Economic/Technical Realm (Cost Offloading): Signals like "Logistical Barriers to Voting" and "Student Technology Access Gap" reveal how civic systems demand uncompensated material capital (time off work, childcare, private fundraising) as a prerequisite for basic entry.

Institutional Protection (Risk-Avoidance): Signals like "Civics Talent Pipeline Shortage" and "Anemic, Uneven Participation" demonstrate how civic organizations favor low-risk, predictable interactions over open, responsive public accountability.

Triangulated Force: The theme connects two distinct forces: institutions closing themselves off to lower their risk, and individuals withdrawing because the cost of entry is too high and yields zero agency.

What does not fit
"Public trust and resources eroded" (Current Title): This title describes passive decay or damage ("eroded"), which conceals the active structural choices—such as automated PR buffering and rigid entry barriers—that cause voters and workers to disengage in the first place.

Heterogeneity of Women in Leadership vs. K-12 Student Tech: The signal "Women Still Under-Represented" reflects political elite gatekeeping and cultural power-hoarding, whereas "Student Technology Access Gap" reflects public sector budget shortfalls. Pairing them under a single theme stretches the mechanism thin.

Sharpening question
Are citizens disengaged because public resources are scarce, or because institutions have engineered an asymmetric relationship where citizens absorb all the effort while the institution retains all the control?
