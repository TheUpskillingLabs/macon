# Untitled

> **Evidence · Evidence** — a card in a Frame Creation web map.
> Built from 2 signal(s). The work on this page is to *investigate the field*, not to solve.

## What these signals jointly establish
*Two or more signals triangulating on one claim. State the claim they make together.*

## What kind of evidence is this?
*Decide the movement first — are you excavating the known problem (Archaeology & Context: history, counterfactual, problem, boundary, flux) or widening to the players and values of the field (Field mapping: player, value)? Classify it once the situation is mapped, then deepen with the matching prompts.*

---

## Evidence & sources
*Primary (from the situation itself — interviews, field notes, documents) and secondary (literature, data, prior art). Attach files below; list and annotate them here.*

## Where I'm not sure
*Your confidence. What would change your mind? What would falsify this?*

## Whose voice is still missing
*Who hasn't been heard yet — and how would they complicate this?*

Analytical Movement & Frame Creation Classification
Let's locate this evidence card within Dorst's Frame Creation methodology:

The movement here sits at the intersection of FIELD MAPPING (identifying who is missing from the field) and ARCHAEOLOGY & CONTEXT (excavating how institutional onboarding pathways are structured).

Plausible Classification Types
Player (Field Mapping): This is the strongest candidate. Both signals center on who enters the field—specifically the practices, currencies, and entry conditions that regulate access for both paid workers (the junior civics workforce) and unpaid actors (participating citizens). The field is currently structured around exclusive currencies that filter out broad participation.

Boundary (Archaeology & Context): A strong alternative. You can interpret these signals as a hard structural boundary—an implicit rule that says, "Entry into this system requires pre-existing social capital, specialized legibility, or high personal bandwidth."

The Trade-Off: Classifying this as a Player frame helps you focus on stakeholder practices, incentives, and currency exchanges (e.g., what makes a junior role viable, who gets listened to). Classifying it as a Boundary frames it as an institutional filter that actively locks out non-traditional actors.

Through-line candidate
Asymmetrical friction in onboarding and legibility: institutional pathways require high upfront cultural or professional capital to navigate, concentrating influence among well-resourced actors while systematically starving entry-level roles and broader civic participation.

Why this fits
"Civics Talent Pipeline Shortage": Demonstrates how formal junior roles fail to attract or retain entry-level talent, pointing to compensation, legibility, or professional pathway breakdowns in the workforce.

"Anemic, Uneven Participation": Shows how informal civic spaces selectively elevate voices that already know how to navigate institutional mechanisms, creating a steep tax on everyday participants.

Shared condition: Both signals describe a system where the "cost of entry"—whether in time, knowledge, or economic sacrifice—is tuned too high for non-insiders to sustain involvement.

What does not fit
Professional vs. Voluntary divergence: The first signal addresses paid, formal employment (elections/civics workforce), while the second addresses unpaid, democratic expression (public participation). Conflating a labor market shortage with broad civic apathy risks blurring two distinct institutional failure points.

Lack of signal on "why": The contents don't specify why the talent pipeline is short (e.g., low pay, political harassment, lack of awareness) or why participation is uneven (e.g., meeting times, systemic distrust). The current evidence names the symptom without revealing the exact structural gate.

Sharpening question
Is the talent shortage caused by a lack of institutional recruitment/outreach, or are the actual working conditions and entry barriers driving interested people away once they look inside?
