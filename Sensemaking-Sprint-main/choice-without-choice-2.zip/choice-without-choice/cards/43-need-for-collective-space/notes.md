# Untitled

> **Evidence · Evidence** — a card in a Frame Creation web map.
> Built from 2 signal(s). The work on this page is to *investigate the field*, not to solve.

## What these signals jointly establish
*Two or more signals triangulating on one claim. State the claim they make together.*

## What kind of evidence is this?
*Decide the movement first — are you excavating the known problem (Archaeology & Context: history, counterfactual, problem, boundary, flux) or widening to the players and values of the field (Field mapping: player, value)? Classify it once the situation is mapped, then deepen with the matching prompts.*

---

## Evidence & sources
*Primary (from the situation itself — interviews, field notes, documents) and secondary (literature, data, prior art). Attach files below; list and annotate them here.*

## Where I'm not sure
*Your confidence. What would change your mind? What would falsify this?*

## Whose voice is still missing
*Who hasn't been heard yet — and how would they complicate this?*

Analytical Movement & Frame Creation Classification
Let's locate this evidence card within Dorst's Frame Creation methodology:

The movement here is ARCHAEOLOGY & CONTEXT—excavating how the current system functions as-is and identifying where structural friction locks actors into helplessness.

Plausible Classification Types
Boundary (Archaeology & Context): This is the strongest candidate. Both signals point to a hard, institutional wall—a nonnegotiable boundary where the system shields itself from authentic human input. Representatives use automated PR boilerplate to block real dialogue, and narrative control in media creates a high personal cost that blocks qualified candidates from entering the field.

Flux (Archaeology & Context): A plausible alternative. You could interpret the pervasive sense of disempowerment and disconnection not as a fixed wall, but as a point of instability—a growing legitimacy crisis where traditional feedback loops have fractured and new forms of collective agency are trying to emerge.

The Trade-Off: Classifying this as a Boundary frames the institutional self-defense mechanics (PR boilerplate, media scrutiny) as rigid constraints to design around or dismantle. Classifying it as Flux treats the widespread sense of "talking into a void" as a tipping point where citizens are actively primed for a paradigm shift.

Through-line candidate
The institutional substitution of transactional PR for genuine reciprocal agency: power structures protect themselves by replacing authentic two-way dialogue with risk-managed communication, transforming citizens from active participants into managed audiences.

Why this fits
"Constituent Mail Black Hole": Shows how institutions deploy strategist-polished boilerplate to neutralize incoming constituent intent, replacing a relational conversation with a one-way broadcast.

"Complacency & Candidate Deterrence": Highlights how media-driven narrative control raises the personal risk of running for office, driving potential leaders away and leaving citizens with no visible path to exert meaningful influence.

Shared condition: Both signals describe a machinery designed to minimize risk for insiders while rendering outside civic action futile and performative.

What does not fit
"Need for collective space" (Current Title): The title asserts a specific missing solution (physical/social space), but the signals don't actually describe a spatial deficit—they describe a breakdown in institutional responsiveness and perceived agency.

Self-directed voter complacency: The first signal mentions citizen "complacency," but the second signal reveals that citizens are actually attempting direct communication (writing letters/emails). The bottleneck isn't voter apathy; it's systemic unresponsiveness.

Sharpening question
Is the core breakdown that citizens lack accessible channels to assemble together, or that existing institutional channels actively filter out human authenticity to avoid risk?