# Accountability

*Evidence · Evidence*

Representatives face no consequences for lying or committing crimes, which encourages them to continue doing so.

## Built from

  - Signal "Representatives Without Accountability": Representatives don't seem to answer to the people, and replacing them changes little — new reps inherit the same voting patterns, with the two-party system and polarization at the crux.
  - Signal "Accountability for Public Lies": Telling the truth — and holding liars accountable and responsible — is named as the missing piece of civic life.
  - Signal "Performative Bipartisanship": Statements, town halls, and pledges perform collaboration without doing it; missing is a structured, sprint-like way for people who are supposed to disagree to define a shared problem and build something together.
