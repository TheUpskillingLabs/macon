# Undisclosed influence over the terms of public judgment:

> **Super-theme** — a card in a Frame Creation web map.
> Built from 6 signal(s). The work on this page is to *investigate the field*, not to solve.

## The convergence
*Where multiple themes meet at a deeper level. What do they share that none names alone?*

## Frame-readiness test
*Try it: "If this situation is approached as if it is [this], then ___." Does the sentence open new possibilities, or just restate?*

## The lens test
*Could someone outside your field understand this as a way of seeing the whole situation?*

## What it makes newly visible
*What becomes thinkable under this lens that wasn't before?*

---

## Evidence & sources
*Primary (from the situation itself — interviews, field notes, documents) and secondary (literature, data, prior art). Attach files below; list and annotate them here.*

## Where I'm not sure
*Your confidence. What would change your mind? What would falsify this?*

## Whose voice is still missing
*Who hasn't been heard yet — and how would they complicate this?*
