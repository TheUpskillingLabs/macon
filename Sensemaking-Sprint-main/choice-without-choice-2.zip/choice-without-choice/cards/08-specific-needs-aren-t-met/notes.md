# Specific Needs aren't Met

*Theme*

Communities aren't able to communicate where they need help or where help is needed.

Even if they could, people don't know how to help.

Therefore, the community's needs aren't met.

## Built from

  • Pattern: Lack of Specific Education — Communities don't have an easy way to educate people regarding their specific                                                                                                                                                                                          needs.                                                                                                                              
    • Evidence: Community Coordination — Communities don't have an easy way to make needs known and recruit volunteers.
      - Signal "Campus–Neighborhood Disconnection": There is no single, easy channel for a university community and its neighbors to trade information and opportunities — student jobs, local events, programs, and campus resources live in scattered slices.
      - Signal "Volunteer Burnout & Knowledge Transfer": Local volunteer roles, such as PTA leadership, fall on a few individuals. There is a need for tools to reduce the operational burden and retain institutional knowledge as volunteer leadership turns over.
      - Signal "Complacency & Candidate Deterrence": The average citizen doesn't feel they can make a difference, and good people stay away from political office because media can form any narrative it wants about them.
      - Signal "Anemic, Uneven Participation": Civic participation is thin, and only some voices get heard and lifted.
      - Signal "Cross-Agency Coordination Failure": Constituent problems take years to solve because coordinating local, federal, and neighboring-state agencies, private entities, and residents is nearly impossible — stakeholders claim jurisdiction for credit and duck it for problem-solving, at great cost to unpaid commissioners.
    • Evidence: Education — People don't know how things work or how to change them.         
      - Signal "Broad Civic Disengagement": Many people are not engaged in local or national politics, don't know who the candidates are or what they stand for, and don't vote — despite candidate forums and get-out-the-vote efforts.
      - Signal "Misunderstood Pace of Government": Constituents misjudge who holds which powers and how fast government was designed to move, so legitimate slowness reads as failure — and stretched congressional staff can't give every issue the weight visitors expect.
      - Signal "Local Candidate Information Gaps": Voters lack easily accessible, actionable information about local county-level candidates, often relying heavily on name recognition from campaign signs.
      - Signal "Uncontested Local Candidate Transparency": It is incredibly difficult to research the records of local election candidates, especially those running uncontested or without a communications budget, leaving voters feeling uninformed.
      - Signal "Logistical & Educational Barriers to Voting": Voting is burdened by physical hurdles (childcare, time off work) and a lack of plain-language education on how local elections directly impact citizens' daily lives.
      - Signal "Ranked Choice Voting Education": The implementation of ranked choice voting lacks sufficient public education to help voters understand its systemic benefits and how it changes voting behaviors.
      - Signal "Ranked-Choice Confusion Persists": Voters remain confused about how ranked choice voting works and still lack clear, unbiased information about the candidates themselves.
      - Signal "Last-Mile Resource Disconnect": Programs, grants, and services exist on paper, but communities often don't know about them or can't navigate them — the gap is grassroots outreach, trusted local partners, and hands-on navigation support, not new programs.
      - Signal "Hopelessness & Lack of Election Information": Voters feel hopeless and lack basic awareness of when local elections occur, relying on passive information like mailers or word of mouth.
      - Signal "No Playbook for Good Citizenship": There is no clear guide to the daily, weekly, and monthly steps of being an informed, participating citizen — the information is scattered everywhere, and the whole project feels overwhelming.
      - Signal "Unexplained Ballot Roles": Even where ranked-choice mechanics were well taught, voters lack a plain-language breakdown of what each office on the ballot actually does, leaving first-time voters guessing at the roles they're electing.
  • Pattern: Lack of Communication — People aren't talking to each other.                                                                                                                                             
    • Evidence: Community Coordination — Communities don't have an easy way to make needs known and recruit volunteers.
      - Signal "Campus–Neighborhood Disconnection": There is no single, easy channel for a university community and its neighbors to trade information and opportunities — student jobs, local events, programs, and campus resources live in scattered slices.
      - Signal "Volunteer Burnout & Knowledge Transfer": Local volunteer roles, such as PTA leadership, fall on a few individuals. There is a need for tools to reduce the operational burden and retain institutional knowledge as volunteer leadership turns over.
      - Signal "Complacency & Candidate Deterrence": The average citizen doesn't feel they can make a difference, and good people stay away from political office because media can form any narrative it wants about them.
      - Signal "Anemic, Uneven Participation": Civic participation is thin, and only some voices get heard and lifted.
      - Signal "Cross-Agency Coordination Failure": Constituent problems take years to solve because coordinating local, federal, and neighboring-state agencies, private entities, and residents is nearly impossible — stakeholders claim jurisdiction for credit and duck it for problem-solving, at great cost to unpaid commissioners.
    • Evidence: Cloistering — People inside communities don't talk to people outside their communities.
      - Signal "Loneliness as a Civic Problem": The social scaffolding that once created accountability in how people form relationships has dissolved with nothing replacing it — an isolation epidemic treated as a private matter rather than missing civic infrastructure.
      - Signal "Volunteer Burnout & Knowledge Transfer": Local volunteer roles, such as PTA leadership, fall on a few individuals. There is a need for tools to reduce the operational burden and retain institutional knowledge as volunteer leadership turns over.
      - Signal "Anemic, Uneven Participation": Civic participation is thin, and only some voices get heard and lifted.
      - Signal "Campus–Neighborhood Disconnection": There is no single, easy channel for a university community and its neighbors to trade information and opportunities — student jobs, local events, programs, and campus resources live in scattered slices.
      - Signal "Missing Dialogue Across Difference": People who hold differing views about a topic rarely talk with each other; new civic-engagement software is being tried, with only some success.
      - Signal "Political Bubbles & NIMBYism": Citizens are highly polarized and isolated in social bubbles, proposing solutions or pushing back on reforms without understanding the broader impacts, trade-offs, or equity implications beyond their circles.
      - Signal "Constituent Mail Black Hole": Letters and emails to representatives feel like talking into a void — heartfelt messages come back as generic, strategist-polished boilerplate.
    • Evidence: Fear — Outside civic discourse, people are afraid of talking to each other.
      - Signal "Political Bubbles & NIMBYism": Citizens are highly polarized and isolated in social bubbles, proposing solutions or pushing back on reforms without understanding the broader impacts, trade-offs, or equity implications beyond their circles.
      - Signal "Missing Dialogue Across Difference": People who hold differing views about a topic rarely talk with each other; new civic-engagement software is being tried, with only some success.
      - Signal "Loneliness as a Civic Problem": The social scaffolding that once created accountability in how people form relationships has dissolved with nothing replacing it — an isolation epidemic treated as a private matter rather than missing civic infrastructure.
      - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
