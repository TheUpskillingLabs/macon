  • Evidence: Barriers to Engage — Entry ways into civic engagement either hard to navigate or does not have strong recruitment. 
    - Signal "Civics Talent Pipeline Shortage": There is a noticeable shortage of talent to fill junior roles within the civics and elections workforce.
    - Signal "Anemic, Uneven Participation": Civic participation is thin, and only some voices get heard and lifted.
  • Evidence: Need for collective space  — People are feeling diconnected and disempowered. 
    - Signal "Complacency & Candidate Deterrence": The average citizen doesn't feel they can make a difference, and good people stay away from political office because media can form any narrative it wants about them.
    - Signal "Constituent Mail Black Hole": Letters and emails to representatives feel like talking into a void — heartfelt messages come back as generic, strategist-polished boilerplate.