# Untitled

> **Pattern** — a card in a Frame Creation web map.
> Built from 4 signal(s). The work on this page is to *investigate the field*, not to solve.

## The mechanism
*Not a topic — a mechanism. Cause → effect, with moving parts. What makes this happen?*

## When and where it recurs
*The conditions under which the pattern shows up. Who's affected, in what context?*

## How the evidence beneath supports it
*Walk each evidence card: how does it establish the mechanism? Where is the chain strongest and weakest?*

## What would have to change to break it
*The leverage points — named, not yet acted on.*

## Where it doesn't hold
*Counter-cases. Honest patterns name their own exceptions.*

---

## Evidence & sources
*Primary (from the situation itself — interviews, field notes, documents) and secondary (literature, data, prior art). Attach files below; list and annotate them here.*

## Where I'm not sure
*Your confidence. What would change your mind? What would falsify this?*

## Whose voice is still missing
*Who hasn't been heard yet — and how would they complicate this?*

Frame Creation Level: Pattern Synthesis
Now that we are stepping up the ladder from Evidence to Pattern, our objective shifts: we are no longer just classifying isolated signals, but naming the recurring, self-reinforcing mechanism that links these two evidence clusters together (Barriers to Engage + Need for collective space).

Through-line candidate
Institutional self-preservation through asymmetric friction and risk-managed buffering: civic structures maintain operational stability by projecting high barrier costs at entry and deploying automated, one-way messaging at exit, actively draining citizen agency to protect incumbents and political insiders from unscripted public accountability.

Why this fits
"Constituent Mail Black Hole" & "Civics Talent Pipeline Shortage": Demonstrates how institutions protect their internal workflows from unpredictable human input—representatives use strategist-polished boilerplate to filter out constituents, while civic organizations fail to build accessible entryways for incoming workers.

"Complacency & Candidate Deterrence": Shows the systemic consequence of this risk-aversion—media scrutiny and narrative warfare raise the personal risk for candidates, while citizens default to learned helplessness ("can't make a difference") when they realize the system is built to deflect them.

"Anemic, Uneven Participation": Illustrates how asymmetric entry friction acts as a filter, ensuring that only highly resourced, institutionally fluent, or persistent actors ever reach decision-makers.

What does not fit
"Civic engagement happening in silos and per issue" (Current Description): The signals in this cluster describe institutional deflection, agency drain, and high barriers to entry—they do not describe issue-based fragmentation, single-issue activism, or siloed organizational structures. The description mischaracterizes the actual mechanism present in the data.

"Civics Talent Pipeline Shortage" vs. General Citizen Apathy: Professional labor market friction (recruiting junior election workers) operates on economic and workplace security drivers that are distinct from why an everyday constituent feels disempowered when sending a letter to a congressperson.

Sharpening question
Is citizen disengagement a passive side-effect of complex bureaucratization, or an active structural strategy designed to keep public pressure manageable for political insiders?
