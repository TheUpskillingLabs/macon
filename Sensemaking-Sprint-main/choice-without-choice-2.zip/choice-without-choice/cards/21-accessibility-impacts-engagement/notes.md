# Untitled

> **Evidence · Evidence** — a card in a Frame Creation web map.
> Built from 2 signal(s). The work on this page is to *investigate the field*, not to solve.

## What these signals jointly establish
*Two or more signals triangulating on one claim. State the claim they make together.*

## What kind of evidence is this?
*Decide the movement first — are you excavating the known problem (Archaeology & Context: history, counterfactual, problem, boundary, flux) or widening to the players and values of the field (Field mapping: player, value)? Classify it once the situation is mapped, then deepen with the matching prompts.*

---

## Evidence & sources
*Primary (from the situation itself — interviews, field notes, documents) and secondary (literature, data, prior art). Attach files below; list and annotate them here.*

## Where I'm not sure
*Your confidence. What would change your mind? What would falsify this?*

## Whose voice is still missing
*Who hasn't been heard yet — and how would they complicate this?*
Analytical Movement & Frame Creation Classification
Let's locate this evidence card within Dorst's Frame Creation framework:

The core movement here is ARCHAEOLOGY & CONTEXT—excavating the concrete, everyday systemic barriers and resource taxes embedded in the current as-is state of local voting.

Plausible Classification Types
Boundary (Archaeology & Context): This is the strongest candidate. The signals describe structural nonnegotiables—hard material walls (unpaid leave, lack of childcare, opaque bureaucratic language) that make participation functionally impossible for working-class citizens unless they possess surplus time and economic safety nets.

Problem (Archaeology & Context): A plausible secondary candidate. You can view this as a bounded operational gap—a failure in civic service design where basic information is not delivered in plain language and voting logistics are poorly adapted to the working hours of everyday citizens.

The Trade-Off: Classifying this as a Boundary frames these barriers as structural, class-based gatekeeping mechanisms (a "tax on participation"). Classifying it as a Problem frames it as an operational delivery breakdown in local election administration and civic education.

Through-line candidate
The uncompensated resource tax on civic participation: democratic engagement assumes an ideal citizen with excess time, flexible hourly wage structures, domestic coverage, and political literacy—forcing resource-constrained working adults to absorb severe personal costs just to exercise a basic right.

Why this fits
"Logistical & Educational Barriers to Voting": Directly illustrates the material cost structure (securing childcare, forfeiting hourly wages, navigating bureaucratic jargon) required just to place a vote.

"Local Candidate Information Gaps": Demonstrates how the high time cost of researching obscure local candidates forces working adults to rely on quick, low-effort heuristics like yard signs rather than policy analysis.

Shared condition: Both signals show that participation is gated not by lack of civic interest, but by an institutional failure to subsidize or reduce the physical and cognitive labor required to engage.

What does not fit
"Ladder gap for disenfranchised" (Current Description): The current description asserts that marginalized groups face a wider "ladder gap," but neither signal explicitly names historical disenfranchisement or specific marginalized populations—they focus broadly on time, income, and local candidate visibility.

Visual name recognition vs. structural logistics: Relying on yard signs is a heuristic information shortcut, whereas missing work or arranging childcare is a material economic constraint. One is cognitive convenience; the other is operational friction.

Sharpening question
Is the primary friction that voters lack plain-language candidate data, or that the physical act of voting requires material sacrifices (money, time, childcare) that low-income citizens simply cannot afford to make?