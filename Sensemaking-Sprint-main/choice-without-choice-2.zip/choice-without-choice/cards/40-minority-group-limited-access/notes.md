# Untitled

> **Evidence · Evidence** — a card in a Frame Creation web map.
> Built from 2 signal(s). The work on this page is to *investigate the field*, not to solve.

## What these signals jointly establish
*Two or more signals triangulating on one claim. State the claim they make together.*

## What kind of evidence is this?
*Decide the movement first — are you excavating the known problem (Archaeology & Context: history, counterfactual, problem, boundary, flux) or widening to the players and values of the field (Field mapping: player, value)? Classify it once the situation is mapped, then deepen with the matching prompts.*

---

## Evidence & sources
*Primary (from the situation itself — interviews, field notes, documents) and secondary (literature, data, prior art). Attach files below; list and annotate them here.*

## Where I'm not sure
*Your confidence. What would change your mind? What would falsify this?*

## Whose voice is still missing
*Who hasn't been heard yet — and how would they complicate this?*

Analytical Movement & Frame Creation Classification
Let's locate this evidence card within Dorst's Frame Creation methodology:

The movement here sits at the boundary between FIELD MAPPING (analyzing how specific groups of players are positioned) and ARCHAEOLOGY & CONTEXT (excavating structural ceilings and resource deficits in the current system).

Plausible Classification Types
Boundary (Archaeology & Context): This is a strong candidate. Both signals point to systemic ceilings—hard, persistent barriers where institutional resource allocation and political gatekeeping cap the advancement and agency of specific demographics (students lacking infrastructure; women locked out of leadership parity).

Player (Field Mapping): A plausible alternative. You can interpret these signals through the lens of specific demographic cohorts (women leaders, public school students) whose practices, capital, and access conditions are systematically undervalued or underfunded within the broader field.

The Trade-Off: Classifying this as a Boundary keeps the focus on the institutional wall (funding caps, gatekeeping structures). Classifying it as Player shifts the focus to how specific cohorts are systematically under-resourced and denied leverage compared to dominant actors.

Through-line candidate
Systemic under-investment and gatekeeping at foundational pipelines: institutional structures default to under-resourcing non-dominant cohorts at early development stages—whether in digital training tools or political entryways—forcing reliance on unsustainable workarounds like individual grit or local fundraising.

Why this fits
"Student Technology Access Gap": Illustrates how public funding models fail to provide baseline tools for skill development, forcing communities to rely on band-aid stopgaps (grassroots fundraising, lobbying) that cannot scale.

"Women Still Under-Represented": Highlights how institutional gatekeeping persists at senior leadership levels even when individual actors actively compete ("even as women run for highest offices").

Shared condition: Both signals point to a structural pattern where marginalized or non-dominant groups are expected to overcome institutional deficits through extraordinary individual effort rather than structural equity.

What does not fit
Extreme thematic gap (Students vs. Women in Office): A local K-12 technology funding deficit and the national under-representation of women in political leadership operate on fundamentally different power dynamics, institutional arenas, and resource scales. Forcing them into a single "minority access" card dilutes both.

"Minority group limited access" (Current Title): Women make up over 50% of the population, and public school students represent a universal age demographic—neither group is accurately categorized as a "minority group." The current title uses a catch-all diversity label rather than naming the actual actors involved.

Sharpening question
Are these two signals connected by a genuine underlying mechanism, or were they grouped together simply because both describe a vulnerable or under-represented population?