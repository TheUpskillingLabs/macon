# Socially-Validated Misinformation Beats Fact

*Pattern*

Voters — teens forming first civic judgments and adults with years of voting history alike — act on information that feels true because it's socially validated, rather than information that's actually been verified, so engaged, "informed" citizens can end up voting against their own family's and community's material interest without realizing it.

## Built from

  • Evidence: Engaging in voting understanding what's true — Youth's ability in understanding what is true may influence their interest in participating in elections and civic life.
    - Signal "Teens and civic participation": How can teens be better prepared and engaged to actively participate in civic life?
    - Signal "K-12 education on truth vs. alternative facts": Are K-12 able to help students understand truth from Alternative Facts in politics?
  • Evidence: Feeling your vote matters for your family — Feeling powerful at the ballot box to make direct difference for your family's well-being.
    - Signal "Voting against family interests": Why do people make choices in elections that go against their family's interests?
    - Signal "Feeling powerful at the ballot box": How can people who feel they have no power see themselves as powerful at the election box?
