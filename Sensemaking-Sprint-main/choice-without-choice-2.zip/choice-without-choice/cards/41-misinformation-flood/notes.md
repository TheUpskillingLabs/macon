# Untitled

> **Evidence · Evidence** — a card in a Frame Creation web map.
> Built from 2 signal(s). The work on this page is to *investigate the field*, not to solve.

## What these signals jointly establish
*Two or more signals triangulating on one claim. State the claim they make together.*

## What kind of evidence is this?
*Decide the movement first — are you excavating the known problem (Archaeology & Context: history, counterfactual, problem, boundary, flux) or widening to the players and values of the field (Field mapping: player, value)? Classify it once the situation is mapped, then deepen with the matching prompts.*

---

## Evidence & sources
*Primary (from the situation itself — interviews, field notes, documents) and secondary (literature, data, prior art). Attach files below; list and annotate them here.*

## Where I'm not sure
*Your confidence. What would change your mind? What would falsify this?*

## Whose voice is still missing
*Who hasn't been heard yet — and how would they complicate this?*

Analytical Movement & Frame Creation Classification
Let's locate this evidence card within Dorst's Frame Creation methodology:

The movement here sits between ARCHAEOLOGY & CONTEXT (excavating how the information system functions as-is) and FIELD MAPPING (analyzing how political actors leverage currency and manipulate practices).

Plausible Classification Types
Flux (Archaeology & Context): This is the strongest candidate. Disinformation and digital noise represent a fundamental point of movement and instability in the field—an environment where historical anchors of trust have dissolved, leaving citizens in a state of epistemological flux where traditional verification tools no longer hold.

Player (Field Mapping): A strong alternative. You can read these signals through the lens of manipulative actors ("digital influencers," "political entities") who actively exploit low civic literacy and distrust as their primary operational strategy to capture power and voter behavior.

The Trade-Off: Classifying this as Flux focuses your frame on the changing rules of reality/trust in the environment (how the information ground has shifted under everyone's feet). Classifying it as Player focuses on strategic manipulation by bad-faith actors who harvest voter vulnerability for specific political payoff.

Through-line candidate
Epistemic exhaustion as a weapon of political manipulation: political entities exploit low civic literacy by flooding digital channels with unverified narratives, intentionally overwhelming citizens' cognitive capacity to verify truth until they collapse into paralyzing distrust and passivity.

Why this fits
"Media Misinformation": Identifies how digital influencers use narrative volume and ambiguity to exhaust citizens' ability to distinguish signal from noise, directly degrading civic engagement.

"Civic Distrust & Disinformation": Shows how political actors strategically exploit this cognitive vulnerability—combining background civic illiteracy with targeted disinformation to activate voters' worst fears and instincts.

Shared condition: Both signals point to a system where truth is not just hidden, but actively drowned out so that emotional reaction replaces rational evaluation.

What does not fit
Broad supply-side vs. intentional demand-side manipulation: "Media Misinformation" broadly critiques general digital media noise, whereas "Civic Distrust & Disinformation" highlights targeted, strategic manipulation by political actors exploiting civic illiteracy. One describes ambient environmental noise; the other describes weaponized intent.

"Lack of civics literacy" as a root cause: The second signal mentions a "lack of civics literacy," which is an internal educational gap rather than an external information attack vector. It sits here as a vulnerable pre-condition rather than an active mechanism.

Sharpening question
Is citizen distrust an accidental casualty of an chaotic digital media environment, or is it the intended output of political strategy designed to make citizens give up on evaluating facts?
