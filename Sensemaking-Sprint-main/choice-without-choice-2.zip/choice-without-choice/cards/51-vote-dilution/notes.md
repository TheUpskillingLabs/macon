# Vote Dilution

*Evidence · Evidence*

Rules are changed to benefit political entities by stopping people voting and diluting the effectiveness of their votes.

## Built from

  - Signal "Structural Election Imbalances": The current electoral system features gerrymandering, dominant two-party privileges, and districts so large that politicians effectively choose their voters.
  - Signal "Mid-Decade Redistricting Shifts": California, Missouri, North Carolina, and Texas will use different congressional maps in 2026 than in 2024 due to voluntary mid-decade redistricting — unusual, and worth watching for how it shifts competitive-district counts.
  - Signal "Restructuring the Political System": A high-level desire to shift the fundamental political structure of the United States to model other international systems.
