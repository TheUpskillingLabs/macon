# Untitled

> **Evidence · Evidence** — a card in a Frame Creation web map.
> Built from 2 signal(s). The work on this page is to *investigate the field*, not to solve.

## What these signals jointly establish
*Two or more signals triangulating on one claim. State the claim they make together.*

## What kind of evidence is this?
*Decide the movement first — are you excavating the known problem (Archaeology & Context: history, counterfactual, problem, boundary, flux) or widening to the players and values of the field (Field mapping: player, value)? Classify it once the situation is mapped, then deepen with the matching prompts.*

---

## Evidence & sources
*Primary (from the situation itself — interviews, field notes, documents) and secondary (literature, data, prior art). Attach files below; list and annotate them here.*

## Where I'm not sure
*Your confidence. What would change your mind? What would falsify this?*

## Whose voice is still missing
*Who hasn't been heard yet — and how would they complicate this?*

Analytical Movement & Frame Creation Classification
Let's position this evidence card on Dorst's Frame Creation map:

The dominant analytical movement here is ARCHAEOLOGY & CONTEXT—excavating the structural breakdown of basic informational delivery and voter orientation in the as-is environment.

Plausible Classification Types
Problem (Archaeology & Context): This is the strongest candidate. Both signals describe a clear, bounded operational difficulty—a systemic failure in the information pipeline for local governance. Basic logistics like election dates, candidate profiles, and voting mechanics are failing to reach residents through passive, low-friction channels, creating an artificial barrier to participation.

History (Archaeology & Context): A plausible secondary candidate. You can view these signals as a record of legacy outreach practices ("candidate forums", physical "mailers", traditional GOTV drives) that have historically lost their efficacy in reaching modern, everyday voters.

The Trade-Off: Classifying this as a Problem frames the friction as an actionable information/awareness delivery failure that can be mapped and restructured. Classifying it as History frames it as an outdated outreach playbook that institutions continue to deploy despite diminishing returns.

Through-line candidate
The cognitive tax of active information seeking in local governance: institutional outreach relies on outdated, high-effort broadcast formats (forums, mailers), forcing residents to manually hunt for basic election logistics until the friction breeds hopelessness and total withdrawal.

Why this fits
"Hopelessness & Lack of Election Information": Highlights how the absence of accessible, timely logistical signals (when elections happen, who is running) transforms simple disorientation into emotional resignation ("hopelessness").

"Broad Civic Disengagement": Demonstrates that traditional institutional efforts (candidate forums, GOTV campaigns) fail because they demand high initiative or physical presence from residents who don't even have foundational context.

Shared condition: Both signals point to a failure of contextual legibility—the system expects voters to push through high friction to find information, rather than embedding clear, low-friction signals into their daily routines.

What does not fit
"Local and National Engagement Cross Roads" (Current Title): Neither signal actually mentions the tension between local and national issues. The title introduces a geographical/jurisdictional conflict that is entirely absent from the constituent signals. The signals are purely about local information deficits and operational disengagement.

Resistance despite effort: The first signal notes disengagement occurs "despite candidate forums," but doesn't explain why forums fail (e.g., poor timing, exclusionary language, inconvenient locations). It leaves a gap in the behavioral mechanics.

Sharpening question
Are citizens disengaged because they genuinely do not care about local outcomes, or because finding out how, when, and who to vote for requires more effort than the perceived impact feels worth?